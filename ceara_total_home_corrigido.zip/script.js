const club = document.querySelector(".club");
const clubButton = document.querySelector(".club-button");

clubButton.addEventListener("click", (event) => {
  event.stopPropagation();
  const isOpen = club.classList.toggle("open");
  clubButton.setAttribute("aria-expanded", isOpen);
});

document.addEventListener("click", () => {
  club.classList.remove("open");
  clubButton.setAttribute("aria-expanded", "false");
});

const track = document.querySelector(".hero-track");
const dots = [...document.querySelectorAll(".dot")];
let current = 0;

function showSlide(index){
  current = (index + 4) % 4;
  track.style.transform = `translateX(-${current * 100}%)`;
  dots.forEach((dot,i)=>dot.classList.toggle("active",i===current));
}
dots.forEach((dot,i)=>dot.addEventListener("click",()=>showSlide(i)));

const players = document.querySelector(".players-track");
document.querySelector(".players-arrow.right").addEventListener("click",()=>players.scrollBy({left:270,behavior:"smooth"}));
document.querySelector(".players-arrow.left").addEventListener("click",()=>players.scrollBy({left:-270,behavior:"smooth"}));

let dragging=false,startX=0,startScroll=0;
players.addEventListener("pointerdown",e=>{
  dragging=true; startX=e.clientX; startScroll=players.scrollLeft;
  players.setPointerCapture(e.pointerId);
});
players.addEventListener("pointermove",e=>{
  if(dragging) players.scrollLeft=startScroll-(e.clientX-startX);
});
players.addEventListener("pointerup",()=>dragging=false);
players.addEventListener("pointercancel",()=>dragging=false);
