# Ceará Total — versão corrigida

Correções desta versão:
- HOME não fica mais roxo permanentemente; roxo aparece no hover.
- Seta do CLUBE refeita com um indicador CSS simples e discreto.
- LEIA MAIS! voltou para cada destaque principal.
- LER MAIS voltou ao lado de NOTÍCIAS.
- VER MAIS voltou acima do carrossel de jogadores.
- ELENCO agora abre uma página própria: elenco.html.
- Os itens HISTÓRIA, HINO, TÍTULOS e TABELAS também são páginas separadas.
- Nenhuma fotografia foi incluída: os espaços de imagem ficam reservados para o usuário adicionar depois.
- Mantidos o carrossel principal, bolinhas, carrossel de jogadores, setas, arrastar e rodapé.
